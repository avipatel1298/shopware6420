<?php declare(strict_types=1);

namespace ICTECHQuickViewPopupWithPastPurchasedProduct;

use Shopware\Core\Framework\Plugin;

class ICTECHQuickViewPopupWithPastPurchasedProduct extends Plugin
{
}